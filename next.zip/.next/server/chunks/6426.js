exports.id=6426,exports.ids=[6426],exports.modules={65102:(e,t,r)=>{Promise.resolve().then(r.bind(r,1023)),Promise.resolve().then(r.bind(r,59663)),Promise.resolve().then(r.bind(r,38767))},6823:(e,t,r)=>{"use strict";r.d(t,{Z:()=>y});var a=r(17577),i=r(41135),s=r(88634),n=r(76527),o=r(8106),l=r(79513),d=r(5637),c=r(2791),h=r(71685),p=r(59459);function u(e){return(0,p.ZP)("MuiSkeleton",e)}(0,h.Z)("MuiSkeleton",["root","text","rectangular","rounded","circular","pulse","wave","withChildren","fitContent","heightAuto"]);var m=r(10326);let v=e=>{let{classes:t,variant:r,animation:a,hasChildren:i,width:n,height:o}=e;return(0,s.Z)({root:["root",r,a,i&&"withChildren",i&&!n&&"fitContent",i&&!o&&"heightAuto"]},u,t)},x=(0,o.F4)`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`,b=(0,o.F4)`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`,f="string"!=typeof x?(0,o.iv)`
        animation: ${x} 2s ease-in-out 0.5s infinite;
      `:null,g="string"!=typeof b?(0,o.iv)`
        &::after {
          animation: ${b} 2s linear 0.5s infinite;
        }
      `:null,w=(0,l.ZP)("span",{name:"MuiSkeleton",slot:"Root",overridesResolver:(e,t)=>{let{ownerState:r}=e;return[t.root,t[r.variant],!1!==r.animation&&t[r.animation],r.hasChildren&&t.withChildren,r.hasChildren&&!r.width&&t.fitContent,r.hasChildren&&!r.height&&t.heightAuto]}})((0,d.Z)(({theme:e})=>{let t=String(e.shape.borderRadius).match(/[\d.\-+]*\s*(.*)/)[1]||"px",r=parseFloat(e.shape.borderRadius);return{display:"block",backgroundColor:e.vars?e.vars.palette.Skeleton.bg:(0,n.Fq)(e.palette.text.primary,"light"===e.palette.mode?.11:.13),height:"1.2em",variants:[{props:{variant:"text"},style:{marginTop:0,marginBottom:0,height:"auto",transformOrigin:"0 55%",transform:"scale(1, 0.60)",borderRadius:`${r}${t}/${Math.round(r/.6*10)/10}${t}`,"&:empty:before":{content:'"\\00a0"'}}},{props:{variant:"circular"},style:{borderRadius:"50%"}},{props:{variant:"rounded"},style:{borderRadius:(e.vars||e).shape.borderRadius}},{props:({ownerState:e})=>e.hasChildren,style:{"& > *":{visibility:"hidden"}}},{props:({ownerState:e})=>e.hasChildren&&!e.width,style:{maxWidth:"fit-content"}},{props:({ownerState:e})=>e.hasChildren&&!e.height,style:{height:"auto"}},{props:{animation:"pulse"},style:f||{animation:`${x} 2s ease-in-out 0.5s infinite`}},{props:{animation:"wave"},style:{position:"relative",overflow:"hidden",WebkitMaskImage:"-webkit-radial-gradient(white, black)","&::after":{background:`linear-gradient(
                90deg,
                transparent,
                ${(e.vars||e).palette.action.hover},
                transparent
              )`,content:'""',position:"absolute",transform:"translateX(-100%)",bottom:0,left:0,right:0,top:0}}},{props:{animation:"wave"},style:g||{"&::after":{animation:`${b} 2s linear 0.5s infinite`}}}]}})),y=a.forwardRef(function(e,t){let r=(0,c.i)({props:e,name:"MuiSkeleton"}),{animation:a="pulse",className:s,component:n="span",height:o,style:l,variant:d="text",width:h,...p}=r,u={...r,animation:a,component:n,variant:d,hasChildren:!!p.children},x=v(u);return(0,m.jsx)(w,{as:n,ref:t,className:(0,i.Z)(x.root,s),ownerState:u,...p,style:{width:h,height:o,...l}})})},38767:(e,t,r)=>{"use strict";r.d(t,{VideoBlock:()=>l});var a=r(10326),i=r(17577),s=r(1302);let n=e=>{let[t,r]=(0,i.useState)(),[a,n]=(0,i.useState)(!0),o=(0,i.useMemo)(()=>t?{link:`https://rutube.ru/play/embed/${t.id}`,image:t.thumbnail_url,title:t.title}:{},[t]),l=async()=>{try{let t=await s.h.getLocalVideos();r(t.results.find(t=>t.id===e)),n(!1)}catch(e){console.error("Error fetching:",e.message)}};return(0,i.useLayoutEffect)(()=>void l(),[]),{isLoading:a,video:o}};var o=r(6823);let l=({id:e,className:t})=>{let{video:r,isLoading:i}=n(e);return a.jsx("div",{className:`videoblock ${t||""}`,children:i?a.jsx(o.Z,{height:"100%",variant:"rounded"}):a.jsx("iframe",{src:r.link})})}},37968:(e,t,r)=>{"use strict";r.d(t,{G:()=>i});var a=r(19510);let i=({icon:e,title:t,text:r})=>(0,a.jsxs)("div",{className:"achievement",children:[(0,a.jsxs)("picture",{className:"achievement__icon",children:[a.jsx("source",{srcSet:e}),a.jsx("img",{src:e,alt:t})]}),a.jsx("div",{className:"achievement__title",children:t}),a.jsx("div",{className:"achievement__text",children:a.jsx("p",{children:r})})]})},16202:(e,t,r)=>{"use strict";r.d(t,{ZP:()=>o});var a=r(68570);let i=(0,a.createProxy)(String.raw`C:\web\websites\loaderpro-nextj\src\components\Articles.tsx`),{__esModule:s,$$typeof:n}=i;i.default;let o=(0,a.createProxy)(String.raw`C:\web\websites\loaderpro-nextj\src\components\Articles.tsx#default`)},79460:(e,t,r)=>{"use strict";r.d(t,{_:()=>o});var a=r(68570);let i=(0,a.createProxy)(String.raw`C:\web\websites\loaderpro-nextj\src\components\Cta.tsx`),{__esModule:s,$$typeof:n}=i;i.default;let o=(0,a.createProxy)(String.raw`C:\web\websites\loaderpro-nextj\src\components\Cta.tsx#Cta`)},84998:(e,t,r)=>{"use strict";r.d(t,{n:()=>o});var a=r(68570);let i=(0,a.createProxy)(String.raw`C:\web\websites\loaderpro-nextj\src\components\VideoBlock.tsx`),{__esModule:s,$$typeof:n}=i;i.default;let o=(0,a.createProxy)(String.raw`C:\web\websites\loaderpro-nextj\src\components\VideoBlock.tsx#VideoBlock`)}};